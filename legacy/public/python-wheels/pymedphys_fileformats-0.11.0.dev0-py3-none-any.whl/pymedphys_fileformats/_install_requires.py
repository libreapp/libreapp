install_requires = ["numpy >= 1.12", "pandas", "pymedphys_base >= 0.11.0dev0, < 0.12.0"]
