version_info = [0, 11, 0, "dev0"]
__version__ = "0.11.0dev0"
