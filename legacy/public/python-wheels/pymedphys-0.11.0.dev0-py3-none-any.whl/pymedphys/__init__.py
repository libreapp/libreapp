"""Module docstring."""

from ._version import version_info, __version__

from ._delivery import Delivery
