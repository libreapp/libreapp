install_requires = [
    "numpy >= 1.12",
    "pymedphys_dicom >= 0.11.0dev0, < 0.12.0",
    "pymedphys_utilities >= 0.11.0dev0, < 0.12.0",
]
